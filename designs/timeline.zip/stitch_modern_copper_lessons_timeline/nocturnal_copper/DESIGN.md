---
name: Nocturnal Copper
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#d8c3b3'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#a08d7f'
  outline-variant: '#534438'
  surface-tint: '#ffb77a'
  primary: '#ffb77a'
  on-primary: '#4c2700'
  primary-container: '#d98c45'
  on-primary-container: '#532b00'
  inverse-primary: '#8d4f08'
  secondary: '#c8c6c5'
  on-secondary: '#303030'
  secondary-container: '#474746'
  on-secondary-container: '#b7b5b4'
  tertiary: '#6bd5ed'
  on-tertiary: '#00363f'
  tertiary-container: '#3aabc2'
  on-tertiary-container: '#003b45'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdcc2'
  primary-fixed-dim: '#ffb77a'
  on-primary-fixed: '#2e1500'
  on-primary-fixed-variant: '#6d3a00'
  secondary-fixed: '#e5e2e1'
  secondary-fixed-dim: '#c8c6c5'
  on-secondary-fixed: '#1b1b1c'
  on-secondary-fixed-variant: '#474746'
  tertiary-fixed: '#a8edff'
  tertiary-fixed-dim: '#6bd5ed'
  on-tertiary-fixed: '#001f26'
  on-tertiary-fixed-variant: '#004e5b'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
typography:
  display-lg:
    fontFamily: Newsreader
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Newsreader
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 42px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Newsreader
    fontSize: 32px
    fontWeight: '500'
    lineHeight: 40px
  headline-sm:
    fontFamily: Newsreader
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
  body-lg:
    fontFamily: Newsreader
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Newsreader
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  gutter: 24px
  margin-desktop: 64px
  margin-mobile: 20px
  container-max: 1280px
---

## Brand & Style
This design system evolves the "Classic Copper" aesthetic into a high-end, dark-mode experience tailored for news, editorial, and premium publishing. The brand personality is authoritative yet modern, evoking the feeling of a late-night study or a luxury gallery. 

The design style is **Minimalism** with a **Corporate/Modern** structure. It utilizes heavy whitespace (or "darkspace"), high-quality serif typography, and a restricted color palette to create an atmosphere of focused sophistication. The emotional response should be one of calm, reliability, and intellectual depth.

## Colors
The palette is anchored by a deep charcoal surface (`#121212`) to reduce eye strain and provide a luxurious foundation. The copper accent has been shifted from a traditional matte to a more luminous, vibrant copper (`#D98C45`) to ensure AAA accessibility and visual pop against the dark background.

- **Primary (Luminous Copper):** Used for call-to-actions, active states, and critical highlights.
- **Secondary (Elevated Surface):** Used for cards, navigation bars, and input fields to create subtle depth.
- **Neutral (Deep Charcoal):** The primary background color.
- **Typography:** Headings utilize an off-white (`#F5F5F5`) for maximum clarity, while body text uses a refined light gray (`#B0B0B0`) to maintain a comfortable reading hierarchy.

## Typography
The system leans heavily on **Newsreader** to maintain its authoritative, literary roots. The serif is used for both headlines and body copy to ensure a cohesive editorial feel. To provide a functional counterpoint, **Inter** is introduced for labels, captions, and UI-specific elements where high legibility at small sizes is paramount.

Large display type should use tighter letter spacing and a medium-to-semibold weight to feel "inked" and intentional. Body text is sized generously with a comfortable line height to facilitate long-form reading on OLED screens.

## Layout & Spacing
The layout follows a **Fixed Grid** philosophy for desktop to maintain editorial control over line lengths, transitioning to a **Fluid Grid** for mobile devices.

- **Desktop:** 12-column grid with 24px gutters. The central content container is capped at 1280px to prevent excessive line lengths.
- **Tablet:** 8-column grid with 20px gutters.
- **Mobile:** 4-column grid with 16px gutters and 20px side margins.

A strict 8px spatial rhythm governs all padding and margins, ensuring vertical rhythm is maintained across disparate content types.

## Elevation & Depth
In this dark-mode environment, depth is conveyed through **Tonal Layers** rather than heavy shadows. 

1. **Base (Level 0):** `#121212` - The primary canvas.
2. **Surface (Level 1):** `#1F1F1F` - Used for cards and secondary navigation. 
3. **Overlay (Level 2):** `#2A2A2A` - Used for modals, tooltips, and floating menus.

Instead of traditional shadows, use **Low-contrast outlines** (`#FFFFFF` at 8% opacity) to define the edges of elements against the dark background. This creates a crisp, architectural feel without the "muddy" look of dark shadows on dark backgrounds.

## Shapes
This design system utilizes **Rounded** geometry (`0.5rem` or `8px` base radius). This softened approach balances the formal nature of the serif typography, making the interface feel approachable and modern. Larger containers like cards and modals should use `rounded-lg` (16px) to emphasize the containerized nature of the editorial content.

## Components
- **Buttons:** Primary buttons use the Luminous Copper background with near-black text. Secondary buttons are outlined with the off-white text color.
- **Cards:** Use the Level 1 surface color (`#1F1F1F`) with a subtle 1px border (`#FFFFFF` at 5% opacity). No external shadows.
- **Inputs:** Fields should be a darker shade than the surface they sit on or use a subtle stroke. Focus states must use the Luminous Copper color for the border.
- **Lists:** Separated by thin, low-opacity horizontal rules (`#FFFFFF` at 10%).
- **Chips/Tags:** Use a "ghost" style—transparent background with a 1px copper border and copper text for active categories; gray border and text for inactive.
- **News Feed:** Utilize high-contrast "kicker" text in the Copper accent above headlines to categorize content quickly.